# Homework 1 Discussion

You don't have any "discussion" question for this homework! You will usually
 get a few of these for each homework; this file is where you are expected to
  write your answer to those questions.